Streets of Rogue - WIZARD mod (Windows)
=======================================

Adds a new playable character: THE WIZARD.

Pick "Wizard" on the character select screen (last slot). He's a glass
cannon: fast and clever, but weak in a fistfight. His special ability is
CHAOS MAGIC - every press casts a RANDOM spell:

  FIREBALL      - exploding fire bolt
  FROST BOLT    - freezes whoever it hits
  LIGHTNING     - taser zap
  SHRINK RAY    - makes enemies tiny
  SPIRIT BLAST  - ghost-blaster bolt
  SLEEP DART    - tranquilizer
  BLINK         - teleports YOU somewhere nearby
  WILD SURGE    - something unpredictable happens to YOU...
                  (giant! fast! invisible! tiny! yeeted across the map!)

Spells fire wherever you are aiming. 4 second cooldown.

INSTALL
1. Find the game folder: Steam -> right-click Streets of Rogue -> Manage ->
   Browse local files. (Usually C:\Program Files (x86)\Steam\steamapps\common\Streets of Rogue)
2. Copy EVERYTHING in this zip (BepInEx folder, winhttp.dll,
   doorstop_config.ini) into that folder, next to StreetsOfRogue.exe.
3. Start the game once and quit. If it worked, the file
   BepInEx\LogOutput.log exists and mentions "WizardMod loaded".
   (If nothing happens: right-click the downloaded zip -> Properties ->
   Unblock, then extract again.)

MULTIPLAYER
- EVERY player in the game needs this mod installed (host and clients),
  otherwise the Wizard shows up broken/invisible for whoever lacks it.
- Playing with more than 4 people? Also copy EightPlayers.dll (from the
  SoR-EightPlayers zip) into BepInEx\plugins - the two mods work together.

UNINSTALL
Delete BepInEx\plugins\WizardMod.dll (or the whole BepInEx folder to
remove all mods).
