Streets of Rogue - EightPlayers mod (Windows)
=============================================

Lets up to 8 people play in one game, and auto-configures 8BitDo Zero 2
controllers.

INSTALL
1. Find the game folder: Steam -> right-click Streets of Rogue -> Manage ->
   Browse local files. (Usually C:\Program Files (x86)\Steam\steamapps\common\Streets of Rogue)
2. Copy EVERYTHING in this zip (BepInEx folder, winhttp.dll,
   doorstop_config.ini) into that folder, next to StreetsOfRogue.exe.
3. Start the game once and quit. If it worked, the file
   BepInEx\LogOutput.log exists and mentions "EightPlayers loaded".
   (If nothing happens: right-click the downloaded zip -> Properties ->
   Unblock, then extract again.)

RECOMMENDED SETTINGS (once, per PC)
- Steam -> Streets of Rogue -> Properties -> Controller ->
  "Disable Steam Input"  (otherwise Steam swallows the gamepad)
- In game: Settings -> Gameplay -> Auto-Aim: On   (helps small pads aim)

PLAYING TOGETHER
- Everyone must be on the same network.
- Host (one PC): Multiplayer -> LAN -> name + port 7777 -> Host.
  Find the host's IP: press Win+R, type "cmd", run "ipconfig",
  read IPv4 Address (e.g. 192.168.1.23).
- Everyone else: Multiplayer -> LAN -> enter that IP, port 7777 -> Join.

8BITDO ZERO 2 PADS
- Power on in Windows mode: hold X + Start. Pair: hold Select 3 seconds,
  then add "8BitDo Zero 2 gamepad" in Windows Bluetooth settings.
- The mod maps it automatically:
  D-pad move | X attack | A interact | B cancel | Y special
  L inventory | R next item | Select use health | Start menu
