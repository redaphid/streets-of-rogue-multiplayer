Streets of Rogue - EightPlayers mod (Linux)
===========================================

Lets up to 8 people play in one game, and auto-configures 8BitDo Zero 2
controllers.

INSTALL
1. Find the game folder: Steam -> right-click Streets of Rogue -> Manage ->
   Browse local files.
2. Copy EVERYTHING in this zip (BepInEx folder, libdoorstop.so,
   run_bepinex.sh) into that folder, next to StreetsOfRogueLinux.x86_64.
3. Make the script executable:  chmod +x run_bepinex.sh
4. Steam -> Streets of Rogue -> Properties -> General -> Launch Options:

       ./run_bepinex.sh %command%

   If the game then does NOT start (happens with Flatpak Steam, whose
   launch chain the script can't parse), use this instead:

       ./run_bepinex.sh # %command%

5. Start the game once and quit. Success = BepInEx/LogOutput.log exists
   and mentions "EightPlayers loaded".
   If the log does not appear at all and you are NOT on Flatpak, your
   system glibc may be too old for BepInEx's loader - ask for help.

RECOMMENDED SETTINGS (once, per PC)
- Steam -> Streets of Rogue -> Properties -> Controller ->
  "Disable Steam Input"  (otherwise Steam swallows the gamepad,
   especially with the "#" launch options)
- In game: Settings -> Gameplay -> Auto-Aim: On

PLAYING TOGETHER
- Everyone must be on the same network.
- Host (one PC): Multiplayer -> LAN -> name + port 7777 -> Host.
  Host's IP:  ip addr   (look for 192.168.x.x)
- Everyone else: Multiplayer -> LAN -> enter that IP, port 7777 -> Join.

8BITDO ZERO 2 PADS
- Power on in Windows mode: hold X + Start. Pair: hold Select 3 seconds,
  then add "8BitDo Zero 2 gamepad" in Bluetooth settings.
- The mod maps it automatically:
  D-pad move | X attack | A interact | B cancel | Y special
  L inventory | R next item | Select use health | Start menu
